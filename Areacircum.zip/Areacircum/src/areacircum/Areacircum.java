package areacircum;

import java.util.Scanner;

public class Areacircum {

    public static void main(String[] args) {
        float radius;
        double area, circum;
        System.out.println("Enter radius:");
        Scanner user_input = new Scanner(System.in);
        radius = user_input.nextFloat();
        //PI*r*r
        area = 3.14 * radius * radius;//PI*r*r
        circum = 3.14 * 2 * radius;//2*PI*r

        System.out.println("Area of circle is:" + area);
        System.out.println("circum of circle is:" + circum);
    }

}
