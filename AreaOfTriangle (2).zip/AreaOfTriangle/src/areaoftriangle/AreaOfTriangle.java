
package areaoftriangle;
import java.util.Scanner;

public class AreaOfTriangle {

   
    public static void main(String[] args) {
        //area = 1/2*a*b;
        System.out.println("enter value of the a");
        System.out.println("enter value of the b");
        float a,b;
        double area;
        Scanner input = new Scanner(System.in);
        a = input.nextFloat();
        b = input.nextFloat();
    }
   
}
