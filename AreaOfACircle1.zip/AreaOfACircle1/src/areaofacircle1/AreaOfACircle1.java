
package areaofacircle1;
import java.util.Scanner;
public class AreaOfACircle1 {
//Area = pi * r^2 

    public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);

    
    System.out.println("please enter the radius:");
   double radius = scanner.nextDouble(); 
        System.out.println("Area of the circle is:"+ Math.PI * radius * radius);
    }
   

}
